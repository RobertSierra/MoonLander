﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {
	public GameObject player;

	void Update () {
		this.transform.position = player.transform.position + new Vector3(0, 0, -24);
	}
}
