﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Player2D : MonoBehaviour {
	MapGeneratorCave caveGenerator;

	Rigidbody2D playBody;
	Vector2 velocity = Vector2.zero;

	public Slider fuelGauge;
	public Slider healthGuage;

	public float thrusterStrength;
	public float fuel = 100f;
	public float health = 100f;

	public Text crashText;

	public Image lowFuelFlash;
	public float lowFuelFlashTime = 2f;
	bool darken = true;

	// Use this for initialization
	void Start () {
		playBody = GetComponent<Rigidbody2D> ();
		caveGenerator = GameObject.FindGameObjectWithTag ("GameController").GetComponent <MapGeneratorCave> ();
		ResetPosition ();

		lowFuelFlash.color = Vector4.zero;
	}
	
	// Update is called once per frame
	void Update () {
//		if (fuel > 0) {
			velocity = new Vector2 (Input.GetAxisRaw ("Horizontal")/2, Input.GetAxisRaw ("Vertical"));//.normalized * 10;
//		}

		if (Input.GetMouseButtonDown (0)) {
			fuel = 100f;
			ResetPosition ();
		}

		if (fuel <= 15)
			FuelIndicator ();
		else
			lowFuelFlash.color = Color.clear;

		fuelGauge.value = fuel;

		Debug.Log (playBody.velocity);
	}

	void FixedUpdate()
	{
		//playBody.MovePosition (playBody.position + velocity * Time.fixedDeltaTime);
		if (fuel > 0)
			playBody.AddForce (velocity * thrusterStrength * Time.deltaTime);

		if (velocity != Vector2.zero) {
			fuel -= 0.2f;
		}
	}

	void ResetPosition()
	{
		lowFuelFlash.color = Color.clear;
		crashText.text = "";

		playBody.velocity = Vector2.zero;
		this.transform.position = new Vector3 (-(int)(caveGenerator.width / 2) + 13, (int)(-caveGenerator.height / 4)+5, 0f);
	}

	void FuelIndicator()
	{
		if (darken) {
			lowFuelFlash.color = Color.Lerp (lowFuelFlash.color, Color.red, Time.deltaTime * lowFuelFlashTime);
			if (lowFuelFlash.color.a >= 0.7)
				darken = false;
		} else {
			lowFuelFlash.color = Color.Lerp (lowFuelFlash.color, Color.clear, Time.deltaTime * lowFuelFlashTime);
			if (lowFuelFlash.color.a <= 0.2)
				darken = true;
		}
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.tag != "LandingPad" && other.gameObject.tag != "Fuel") {
			fuel = 0;
			crashText.text = "CRASH!!";
		}

		if (other.gameObject.tag == "LandingPad") {
			if (playBody.velocity.x > 2 || playBody.velocity.y > 2 || playBody.velocity.x < -2 || playBody.velocity.y < -2) {
				fuel = 0;
				crashText.text = "CRASH!!";
			}
		}

		if (other.gameObject.tag == "Fuel") {
			if (fuel + 15 > 100)
				fuel = 100;
			else 
				fuel += 15;
		}

		//Debug.Log (other);
	}
}
